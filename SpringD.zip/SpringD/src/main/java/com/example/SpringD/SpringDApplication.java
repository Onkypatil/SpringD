package com.example.SpringD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDApplication.class, args);
	}

}
